$(document).ready(function () {
    // const navItem = $('.nav-item');
    // $(navItem).click(function() {
    //     _this = this
    //     setTimeout(function() {
    //         console.log('123')
    //     }, 3000)
    // })
    // console.log(navItem)
    // $(document).on('click', '.nav-item', function() {
    //     // console.log(this)
    //     console.log('123')
    // })
})