<?php 


    define ('HOST', 'localhost');
    define ('USERNAME', 'phamviethung_phamviethung');
    define ('PASSWORD', 'Toidayhoc123');
    define ('DATABASE', 'phamviethung_ashion');
    define ('PRIVATE_KEY', '234SFDV@!#$3SDFDVNJAKJsdsvsv');

?>