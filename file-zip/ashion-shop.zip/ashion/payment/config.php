<?php
define('URL_API','https://www.nganluong.vn/checkout.api.nganluong.post.php'); // Đường dẫn gọi api
define('RECEIVER','toidayhoc@datdia.com'); // Email tài khoản ngân lượng
define('MERCHANT_ID', '56168'); // Mã merchant kết nối
define('MERCHANT_PASS', '9cf9286010533f0af23cdd10be9b4400'); // Mật khẩu kết nôi
?>

<?php
// define('URL_API','https://www.nganluong.vn/checkout.api.nganluong.post.php'); // ÄĘ°į»¯ng dįŗ«n gį»¨i api
// define('RECEIVER','toidayhoc@datdia.com'); // Email tĆ i khoįŗ£n ngĆ¢n lĘ°į»£ng
// define('MERCHANT_ID', '56168'); // MĆ£ merchant kįŗæt nį»‘i
// define('MERCHANT_PASS', '9cf9286010533f0af23cdd10be9b4400'); // Mįŗ­t khįŗ©u kįŗæt nĆ´i
?>

