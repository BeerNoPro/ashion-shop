
$(document).ready(function() {
    // // func count product order
    // countProductOrder(userId)
    // function countProductOrder(userId) {
    //     $.ajax({
    //         url: 'ajax-api.php',
    //         method: 'GET',
    //         dataType: 'text',
    //         data: {
    //             'countProOrder': 1,
    //             'userId': userId
    //         }, success: function(data) {
    //             console.log(data)
    //         }
    //     })
    // }
    // function handleQuantity() {
    //     $(document).on('click', '.pro-qty .inc', function() {
    //         var price = $(this).closest('tr').find('.cart__price').text();
    //         console.log(price)
    //     })
    // }
})